import React from 'react'

const AddCity = () => {
  return (
    <div className=''>
      city
    </div>
  )
}

export default AddCity
