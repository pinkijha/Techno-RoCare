import React from 'react'

const Home = () => {
  return (
    <div>
      <p>hello</p>
    </div>
  )
}

export default Home
